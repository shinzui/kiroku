# Changelog

## 0.6.0.1 — 2026-10-10

### Other Changes

- Require `kiroku-store ^>=0.11.0.0` for the inspection cohort; the public API is unchanged.

## 0.6.0.0 — 2026-10-10

### Breaking Changes

* Both configurations use validated `BatchSize` and `StreamBufferSize` capacities.
  `KirokuConsumerGroupConfig.groupSize` and `defaultConsumerGroupConfig` take
  validated `ConsumerGroupSize`; smart constructors and read-only accessors are
  re-exported.
* Both configurations add `retryPolicy` (five total deliveries) and
  `handlerStallWarnAfter` (default `Nothing`), forwarded to each underlying worker.
  Pending raw acknowledgements remain pending; enabled warnings are advisory.

### New Features

* Add `kirokuProcessor`, composing single-processor defaults (`Unordered`,
  `Serial`) with the one-second synchronous exception retry guard.

### Other Changes

* Require `kiroku-store ^>=0.10.0.0`.

## 0.5.1.5 — 2026-09-25

### Other Changes

* Require `kiroku-store ^>=0.9.0.1` so adapter consumers receive the idle
  publisher retention fix. The adapter API and behavior are unchanged.

## 0.5.1.4 — 2026-09-25

### Other Changes

* Requires `kiroku-store ^>=0.9`, which requires schema migration `0012` from
  kiroku-store-migrations 0.6.0.0 and serves category reads from the new `$all`
  category index. No source change was required and no adapter API or
  runtime behavior changed.

## 0.5.1.3 — 2026-09-21

### Bug Fixes

* Consumer-group construction now uses a masked ownership ledger. Cancellation
  cannot strand a member between factory return and registration, every
  acquired member receives a shutdown attempt after a later failure, and a
  throwing shutdown no longer replaces the primary construction exception.
* The underlying ack-stream bridge now closes its own subscription-to-monitor
  ownership window and waits for both threads during idempotent shutdown.

### Other Changes

* Require `shibuya-core >=0.10 && <0.11` across the library, tests, lifecycle
  fixture, and benchmark for the coordinated lifecycle release candidate.
* Support `effectful-core` 2.6.1 and 2.7.1.1 or later, while excluding 2.7.0.0
  through 2.7.1.0 because upstream records a per-operation performance
  regression for dynamically dispatched effects.
* Real-store regressions cover duplicate acknowledgement, `AckHalt` replay,
  cancellation after reply but before checkpoint persistence, existing and
  missing checkpoint policies, source failure, retry, and leak-free shutdown.
* Keep the live lifecycle fixture enabled in the repository while making it an
  opt-in Cabal component for source-distribution consumers, so the published
  library does not require the unpublished `kiroku-test-support` package.
* The live restart fixture now streams identities externally, then emits and
  enforces a reconciled per-delivery ledger. This detects duplicate/loss
  compensation without retaining the identity set in the measured process heap.
* The handler-exception documentation now reflects Shibuya's supervised
  immediate-retry finalization behavior.

## 0.5.1.2 — 2026-09-18

### Other Changes

* The test-suite now requires `ephemeral-pg >=0.3.1 && <0.4` (was
  `>=0.2 && <0.3`). The library's dependencies, API and runtime behavior are
  unchanged.

## 0.5.1.1 — 2026-08-16

### Other Changes

* Requires `kiroku-store ^>=0.8`, which adds the `TransientTransactionFailure`
  constructor to `StoreError`. The adapter does not match on `StoreError`, so
  no source change was required and no `shibuya-kiroku-adapter` API or runtime
  behavior changed.

## 0.5.1.0 — 2026-08-15

### Other Changes

* Requires `shibuya-core >=0.9 && <0.10`, which adds the
  `ApplicationFailure DeadLetterCode Text` dead-letter reason.
* `toKirokuDeadLetterReason` now translates `ApplicationFailure` into Kiroku's
  `DeadLetterOther`. The summary is Shibuya's canonical `code: detail`
  rendering, and the structured `reason` JSONB is
  `{"kind":"other","summary":…,"detail":{"code":…,"detail":…}}` so the
  application-owned code is queryable as `reason->'detail'->>'code'` without
  parsing the summary.
* The `PoisonPill`, `InvalidPayload`, and `MaxRetriesExceeded` translations are
  unchanged, so existing `dead_letters` rows keep their encoding. No
  `shibuya-kiroku-adapter` API changed.
* Build with `-Werror=incomplete-patterns`. This package translates between
  dependency-owned sum types, where an upstream constructor addition otherwise
  degrades a translation into a runtime failure behind a green `-Wall` build.

## 0.5.0.2 — 2026-08-13

### Other Changes

* Requires `kiroku-store ^>=0.7` for the new replay-history retention API. No
  `shibuya-kiroku-adapter` API or runtime behavior changed.

## 0.5.0.1 — 2026-08-12

### Other Changes

* Requires `kiroku-store ^>=0.6`, whose exported `Store` effect now offers the
  visible global head position read. No `shibuya-kiroku-adapter` API or runtime
  behavior changed.

## 0.5.0.0 — 2026-08-11

### Breaking Changes

* `KirokuAdapterConfig` and `KirokuConsumerGroupConfig` gain
  `missingCheckpointPolicy`. Their smart constructors default it to
  `FromBeginning`; exhaustive record literals must choose a policy or use the
  smart constructors.
* Requires `kiroku-store ^>=0.5`.

### New Features

* The adapter re-exports `MissingCheckpointPolicy` and forwards it to every
  underlying Kiroku worker. `FromCurrentHead` supports future-only Shibuya
  processors without historical side effects, while `FailIfMissing` preserves
  mandatory checkpoint provisioning. A consumer-group policy is applied
  independently to every member key; existing rows always win.

## 0.4.0.1 — 2026-08-09

### Other Changes

* Requires `kiroku-store ^>=0.4`, whose exported `Store` effect now supports
  durable subscription checkpoint inventory reads. No
  `shibuya-kiroku-adapter` API or runtime behavior changed.

## 0.4.0.0 — 2026-07-11

### Breaking Changes

* `KirokuAdapterConfig` and `KirokuConsumerGroupConfig` gain a
  `queueCapacity` field, defaulting to 16 in the smart constructors.
* Requires `shibuya-core >=0.8 && <0.9` (was `>=0.7`) and `kiroku-store ^>=0.3`.

### Fixed

* Adapter subscriptions now rely on Kiroku's default lossless
  `PauseAndResume` overflow policy instead of pinning fail-fast
  `DropSubscription`.
* `guardKirokuHandlerWith` and `guardKirokuHandler` convert synchronous handler
  exceptions into finalized ack decisions so Kiroku workers are not abandoned
  mid-ack. `kirokuConsumerGroupProcessors` applies the default guard
  automatically.
* `Adapter.source` now has regression coverage for EP-1's termination contract:
  clean shutdown ends the stream normally, while a worker crash is rethrown to
  the stream consumer.
* `kirokuConsumerGroupProcessors` now throws `InvalidConsumerGroup` for
  non-positive group sizes before opening subscriptions, and cleans up already
  created member adapters if a later member fails during construction.
* The package description and Haddocks describe the ack-coupled bridge instead
  of the obsolete no-op ack behavior.

### Known Limitations

* `shibuya-core` still needs upstream fixes for finalize-on-exception in its
  supervised processor and for propagating ingester stream failures from the
  supervised runner. The adapter-side guard is defensive and remains correct
  after those fixes land.

## 0.3.0.0 — 2026-06-05

### Changed

- Require `shibuya-core >=0.7 && <0.8`. `Envelope` now carries a
  `headers :: Maybe Headers` field; `toEnvelope` sets it to `Nothing`,
  because Kiroku events carry no ordered, raw broker headers. W3C trace
  context continues to be surfaced via `traceContext` from event metadata.

## 0.2.0.0 — 2026-05-31

### Breaking Changes

#### Shibuya 0.6 and OpenTelemetry 1.0 semantics

* The adapter now targets `shibuya-core >=0.6 && <0.7` and
  `hs-opentelemetry-api ^>=1.0`.
* `Envelope.attributes` now also carries current OpenTelemetry messaging
  semantic-convention attributes for the Kiroku source:
  `messaging.system = "kiroku"` and `messaging.destination.name` set to the
  subscription name. These override Shibuya's framework defaults on the
  per-message process span while preserving the existing `kiroku.*` attributes.

#### Ack decisions now drive Kiroku checkpointing (plan 40)

* The adapter bridges through `kiroku-store`'s ack-coupled
  `subscriptionAckStream`: each event blocks the Kiroku worker until the Shibuya
  handler's `AckDecision` is finalized, so the decision drives Kiroku
  checkpointing per event. Previously `AckRetry` / `AckDeadLetter` were no-ops.
  * `AckOk` — checkpoint past the event.
  * `AckRetry delay` — redeliver the same event after `delay`, bounded by the
    subscription's retry policy, then dead-letter on exhaustion.
  * `AckDeadLetter reason` — record the event in `kiroku.dead_letters` (reason
    translated to a Kiroku-native `DeadLetterReason`) and advance past it.
  * `AckHalt` — cancels the subscription (unchanged).
* The envelope `attempt` now reports the zero-based redelivery count.
* `Shibuya.Adapter.Kiroku.Convert` exposes `toIngestedAck` (replacing
  `toIngested`), `toKirokuResult`, and `toKirokuDeadLetterReason`.

### New Features

#### Kiroku identity on envelope attributes for end-to-end tracing (MasterPlan 6 EP-5)

* `Envelope.attributes` (previously always empty) is now populated with the
  kiroku identity so it appears on Shibuya's per-message span:
  `kiroku.subscription.name`, `kiroku.event.type`, `kiroku.event.global_position`,
  and — for a consumer-group member — `kiroku.consumer_group.member`. Combined
  with `kiroku-otel`'s native subscription spans, a single trace is followable
  from a kiroku subscription into Shibuya's processing; the keys match on both
  sides.
* `Shibuya.Adapter.Kiroku.Convert` exposes `KirokuEnvelopeAttrs`; `toEnvelope`
  and `toIngestedAck` take it. `kirokuAdapter` derives the subscription name and
  member from its config, so the single-adapter and consumer-group paths are both
  covered. No `shibuya-core` change; the ack-handle logic and trace-context
  propagation are unchanged.

#### `defaultKirokuAdapterConfig` smart constructor

* `defaultKirokuAdapterConfig name target` builds a `KirokuAdapterConfig` with
  recommended defaults (batch size 100, buffer 256, no consumer group,
  `AllEventTypes`, no selector); override individual fields with record-update or
  a generic-lens label (`& #eventTypeFilter .~ …`). Prefer it over a full record
  literal so a future field is inherited at its default automatically — mirrors
  `defaultConsumerGroupConfig` and `kiroku-store`'s `defaultSubscriptionConfig`.
* `KirokuAdapterConfig` and `KirokuConsumerGroupConfig` now derive `Generic`,
  enabling generic-lens label access/update of their fields.

#### Consumer groups as a single partitioned subscription (plan 42)

* `kirokuConsumerGroupProcessors` — present a whole kiroku consumer group as one
  `PartitionedInOrder` unit: a single call yields `N` named `QueueProcessor`s
  (one member adapter each, `ProcessorId "<name>-member-<m>"`), each pinned to
  `(PartitionedInOrder, Serial)`. Replaces the manual `mapM mkMemberAdapter
  [0..N-1]` wiring.
* `KirokuConsumerGroupConfig` + `defaultConsumerGroupConfig` — describe a whole
  group (subscription name, target, group size, batch size, buffer size, and a
  per-member `Concurrency` that must be `Serial`).
* `consumerGroupPolicy` — map a requested per-member `Concurrency` onto the
  validated group policy `(PartitionedInOrder, Serial)`, reusing Shibuya's own
  `validatePolicy` so `Ahead`/`Async` are rejected early with
  `InvalidPolicyCombo` before any subscription opens.
* No `shibuya-core` changes: the helper only consumes existing exports.

#### Event-type filter and selector forwarding (plan 43)

* `KirokuAdapterConfig` and `KirokuConsumerGroupConfig` gain an `eventTypeFilter`
  field (`AllEventTypes` / `OnlyEventTypes (Set EventType)`, default
  `AllEventTypes`), forwarded into the underlying subscription so the adapter
  delivers only the chosen event types. Filtering is worker-side, ahead of the
  ack-coupled bridge, so a filtered-out event never reaches the Shibuya handler,
  is never retried or dead-lettered, and the checkpoint still advances past it.
  `EventTypeFilter (..)` is re-exported.
* Both config records also gain an optional `selector :: Maybe (RecordedEvent ->
  Bool)` field (default `Nothing`) — the opaque escape hatch for filtering on a
  property the type set cannot express (payload, metadata, correlation ids). It
  composes with `eventTypeFilter` as a logical AND and is applied worker-side
  with the same no-stall / checkpoint-advances guarantee. For a consumer group
  the same predicate is applied to every member.

## 0.1.0.0 — 2026-05-23

### New Features

* Initial release.
* `kirokuAdapter` — create a Shibuya `Adapter es RecordedEvent` from a
  Kiroku store handle and subscription configuration.
* `KirokuAdapterConfig` — subscription name, target, batch size, and
  TBQueue buffer size.
* Ack semantics: AckOk/AckRetry/AckDeadLetter are no-ops (checkpoint
  managed by Kiroku); AckHalt cancels the subscription.
* `Shibuya.Adapter.Kiroku.Convert` — RecordedEvent to Envelope mapping.
