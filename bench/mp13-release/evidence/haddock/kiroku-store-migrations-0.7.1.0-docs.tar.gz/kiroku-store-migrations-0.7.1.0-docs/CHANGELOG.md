# Changelog

## 0.7.1.0 — 2026-10-10

### New Features

- Migration 0015 adds one partial byte-ordered name index for catalog and literal-prefix
  reads, preserving existing unique-name and category/event indexes. The transactional
  build requires a write pause on large stores; write-cost evidence and its limitations are recorded
  by MasterPlan 13. Publication remains gated by cumulative acceptance.


## 0.7.0.0 — 2026-10-10

### Breaking Changes

* Migration 0014 adds checked, unindexed subscription target-binding columns and
  removes the unused `stream_name` column. Stop subscription workers before
  applying the cohort's migrations and restart with kiroku-store 0.10.0.0.
  Constant defaults do not rewrite legacy rows.

### New Features

* Migration 0013 derives persisted consumer-group size from existing member rows.
  Incomplete legacy groups refuse on next startup until explicitly resized to
  the intended topology. Both migrations are included in the embedded manifest.

## 0.6.0.0 — 2026-09-25

### Breaking Changes

* New forward migration `0012` adds `kiroku.stream_events.category`, the
  source stream's category on every `$all` junction row, so category reads can
  range-scan an index instead of probing every stream in the category (BUG-2).
  It backfills the column on existing `$all` rows from `streams.category`,
  adds `ck_stream_events_all_category` (`stream_id <> 0 OR category IS NOT
  NULL`), and builds the partial index `ix_stream_events_all_by_category
  (category, stream_version) INCLUDE (original_stream_id) WHERE stream_id =
  0`. kiroku-store 0.9.0.0 requires it.
* Any code that inserts `$all` junction rows directly must now set `category`;
  the check constraint rejects the old five-column shape with SQLSTATE `23514`.
  That includes kiroku-store 0.8 and older, whose appends fail against a
  migrated schema: stop old writers before applying `0012`, and start
  kiroku-store 0.9 after it. No rolling deploy is possible across this
  migration.

### Other Changes

* `0012` runs in one transaction. Its backfill rewrites every `$all` row and
  temporarily disables the `no_update_stream_events` trigger inside that
  transaction; appends block until it commits. On a large store apply it in a
  maintenance window and run `VACUUM (ANALYZE) kiroku.stream_events`
  afterwards.
* The test-suite gains an upgrade case that applies `0012` to a store
  populated with pre-`0012` junction rows and checks the backfill, the
  constraint, the index definition, and the re-enabled trigger. The BUG-1
  upgrade case now bootstraps through `0009` explicitly, so `0010` stays in its
  pending tail.

## 0.5.0.0 — 2026-09-18

### Breaking Changes

* Requires the `pg-migrate` 1.2 series (`pg-migrate`, `pg-migrate-embed`,
  `pg-migrate-import-codd`, `pg-migrate-cli` `^>=1.2.0.0`, was `^>=1.1.0.0`).
  `Kiroku.Store.Migrations` re-exports `MigrationComponent`, `MigrationPlan`,
  `DefinitionError` and `PlanError` from `pg-migrate`, so this major bump
  follows the dependency's. pg-migrate 1.2 has no API or behavior changes
  relative to 1.1: consumers only need to move their own `pg-migrate` bounds
  to `^>=1.2`. The migration payloads, their checksums and the
  `kiroku-store-migrate` executable are unchanged.

### Other Changes

* The test-suite requires `ephemeral-pg >=0.3.1 && <0.4` and
  `pg-migrate-test-support ^>=1.2.0.0`, and builds on its
  `defaultEphemeralConfig` so orphaned clusters from killed runs are reaped.
* The UUIDv7 test now requires the PostgreSQL 18 builtin to exist exactly when
  the server major is 18, and reports which route supplied `kiroku.uuidv7()`.
  A run can no longer pass while exercising a different major than intended.
* The README documents running the suites against both PostgreSQL 17 and 18
  (`just test-matrix`, `just test-pg <major>`).

## 0.4.0.0 — 2026-08-16

### Breaking Changes

* **The payload of migration `0010` is corrected, which changes its checksum.**
  `pg-migrate` keys an applied migration by `(component, migration)` and
  verifies the exact SHA-256 of its payload bytes, so a database that already
  applied `0010` from 0.3.2.0 or 0.3.2.1 will fail every `up` and `verify` with
  a `MigrationChecksumMismatch` until its ledger row is re-baselined. Run
  `ledger-fixups/2026-08-16-rebaseline-0010-checksum.sql` against such a
  database once, before migrating; it rewrites that one checksum and touches
  nothing else. A database that never reached `0010` — every PostgreSQL 17
  upgrade, which is what this release fixes — needs nothing: `0010` is still
  pending there and applies from the corrected payload.

  Editing a released payload is normally forbidden by this package, and a
  forward migration is the documented remedy. There is none available here: the
  withdrawn payload fails at DDL parse time, so no migration ordered after it
  can ever run. 0.3.2.0 and 0.3.2.1 are deprecated on Hackage.

### Fixes

* Migration `0010` no longer defaults `history_retention_leases.lease_id` to an
  unqualified `uuidv7()` (BUG-1). `uuidv7()` is a PostgreSQL 18 builtin; on
  PostgreSQL 17 the name comes from the fallback `0001` installs into the
  Kiroku schema, reachable only through the `search_path` that `0001` itself
  sets. `0010` therefore parsed on a fresh install, where `0001` had just run in
  the same session, and failed with SQLSTATE 42883 on every ordinary upgrade of
  a database already bootstrapped through `0009`. Reported by Kioku; confirmed
  and fixed against PostgreSQL 17.10.

### New Features

* `kiroku.uuidv7()` is now the component's version-independent, always
  schema-qualified UUIDv7 generator. `0010` publishes it on PostgreSQL 18 as an
  alias for the builtin, and PostgreSQL 17 already had it from `0001`'s
  fallback. Migrations after `0001` can name one generator that resolves without
  any session state on every supported PostgreSQL version.
* Added forward migration `0011`, which converges databases that applied the
  withdrawn `0010`: it publishes `kiroku.uuidv7()` where missing and binds
  `lease_id`'s stored default to it. It is a no-op on a database that applied
  the corrected `0010`. Verified on PostgreSQL 17.10 and 18.4: a converged
  database and a fresh install dump identically.

### Other Changes

* The test suite covers the upgrade path that this defect broke — applying the
  pending tail of the plan in a session that never ran `0001` and cannot reach
  the Kiroku schema through `search_path`. The suite connects as role `kiroku`,
  whose default `"$user"` `search_path` entry resolves to the Kiroku schema, so
  every previous case was masked from exactly this class of failure. The new
  case fails on the withdrawn payload against PostgreSQL 17 and passes on the
  corrected one; on PostgreSQL 18 the builtin makes both payloads parse, so
  PostgreSQL 17 coverage is what guards this.
* The `ledger-fixups/` scripts ship in the source distribution.

## 0.3.2.1 — 2026-08-15

### Other Changes

* Built with `ghc-options: -Wall -Werror=incomplete-patterns`, matching every
  other package in the repository. The `kiroku-store-migrate` executable
  renames a local binding that shadowed `Options.Applicative`'s `command`, and
  the test-suite imports `EphemeralPg.Config` for the ambiguous `user` field.
  No library API or runtime behavior changed.

## 0.3.2.0 — 2026-08-13

### New Features

* Added forward migration `0010`, which installs durable replay-history
  retention leases, a per-schema singleton coordinator, a partial active-lease
  index, and statement-level `DELETE`/`TRUNCATE` guards for `events`,
  `stream_events`, and `streams`. Active retention is refused with SQLSTATE
  `KR001` even when the existing hard-delete GUC is enabled.

## 0.3.1.0 — 2026-08-13

### New Features

* Added forward migration `0009`, which publishes the frozen, structurally read-only
  `kiroku.subscription_checkpoints_v1` relation for exact durable subscription-member
  checkpoints. Database readers can receive schema usage and view selection without access to
  Kiroku's private checkpoint table; no role or grant is created automatically.

## 0.3.0.0 — 2026-07-14

### Breaking Changes

* Upgraded `pg-migrate` to 1.1.0.0. `kiroku-store-migrate check` now takes the
  manifest as `--manifest PATH` instead of a positional argument, matching
  `new --manifest`.

### New Features

* `kiroku-store-migrate up` and `repair` accept explicit `--wait` and
  `--no-statement-timeout` overrides; omitting an execution flag now preserves
  the application's configured runner settings instead of discarding them.
* Successful migration, repair, and history-import runs are no longer replaced
  by an error when advisory unlock or statement-timeout restoration fails; the
  durable report is preserved and the cleanup observation attached to it.

### Fixes

* Adding or removing a migration SQL file without listing it in the manifest no
  longer silently reuses a stale compile-time embedding: the embedding module now
  forces GHC to revalidate manifest membership on every build it runs.

## 0.2.0.0 — 2026-07-11

### Breaking Changes

* Migrated the package's runtime from Codd to `pg-migrate`. The public API now
  exports the native `kirokuMigrations` component and `kirokuMigrationPlan`
  instead of Codd settings, runner, ledger-status, and schema-check wrappers.
* Replaced timestamped runtime identities with manifest-ordered `0001` through
  `0007` identities while preserving every SQL payload byte.
* Replaced the Codd CLI and `CODD_*` configuration surface with the standard
  `pg-migrate-cli` command tree and `DATABASE_URL`. `verify` now compares the
  declared plan with the `pgmigrate` ledger; it does not compare live schema
  objects with an expected-schema snapshot.

### New Features

* Added a manifest-backed, compile-time-embedded migration component that
  applications can compose with other libraries in explicit dependency order.
* Added checked-in Codd history mappings and `SamePayload` evidence for safe,
  non-replaying import from current `codd` and legacy `codd_schema` ledgers.
  Shared-ledger consumers can combine Kiroku's exported payloads and mappings
  with their own components before importing.
* Added the standard `pg-migrate-cli` planning, inspection, execution,
  verification, status, and numeric migration-authoring commands.
* Added fresh-apply, rerun, concurrent-apply, strict ledger verification, Codd
  import, partial-row rejection, audit, and source-preservation coverage. The
  full Kiroku store suite now consumes the same native plan through
  `kiroku-test-support`.
* Appended `0008-schema-management-comment`, a non-destructive observable
  native-runner canary. Fresh and imported-prefix tests prove it applies once,
  verifies strictly, and reruns as `AlreadyApplied` without changing historical
  payloads or Codd mappings.

### Changed

* Preserved the seven historical SQL payloads byte-for-byte while moving their
  authoritative ordering to `migrations/manifest`; `migrations.lock` remains
  the source evidence used during Codd history import.
* Removed Codd, `codd-extras`, `file-embed`, and `postgresql-simple` from the
  normal library and executable dependency closure.
* Removed the orphaned Codd expected-schema snapshot, its writer executable, the
  Cabal flag that gated it, and the accompanying Nix closure workaround. Codd
  ledger history import remains supported independently through
  `pg-migrate-import-codd`.

## 0.1.1.0 — 2026-05-31

### New Features

* Forward migration `2026-05-29-15-26-04-add-subscription-dead-letters.sql`:
  creates the `kiroku.dead_letters` table (per consumer-group member, with a
  foreign key to `kiroku.events`) and its recency index, supporting per-event
  dead-letter recording for subscriptions (MasterPlan 6 / plan 40).

## 0.1.0.0 — 2026-05-23

### New Features

* Initial release of the migration package.
* Embeds Kiroku's codd SQL migrations and exposes
  `Kiroku.Store.Migrations`.
* Provides the `kiroku-store-migrate` executable for applying the event store
  schema before application startup.
* Bootstraps the dedicated `kiroku` PostgreSQL schema and installs Kiroku
  tables, indexes, functions, and triggers there.
