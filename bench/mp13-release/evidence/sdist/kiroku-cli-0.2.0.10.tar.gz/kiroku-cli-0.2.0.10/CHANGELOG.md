# Changelog

## 0.2.0.10 — 2026-10-10

### Other Changes

- Require `kiroku-store ^>=0.11.0.0` for the inspection cohort; the public API is unchanged.


## 0.2.0.9 — 2026-10-10

### Other Changes

* Require `kiroku-store ^>=0.10.0.0` so operator consumers resolve the subscription
  hardening cohort. The CLI API and runtime behavior are unchanged.

## 0.2.0.8 — 2026-09-25

### Other Changes

* Require `kiroku-store ^>=0.9.0.1` so CLI users receive the idle publisher
  retention fix. The CLI API and behavior are unchanged.

## 0.2.0.7 — 2026-09-25

### Other Changes

* Requires `kiroku-store ^>=0.9`, which requires schema migration `0012` from
  kiroku-store-migrations 0.6.0.0 and serves category reads from the new `$all`
  category index. No source change was required and no `kiroku-cli` API or
  runtime behavior changed.

## 0.2.0.6 — 2026-08-16

### Other Changes

* Requires `kiroku-store ^>=0.8`, which adds the `TransientTransactionFailure`
  constructor to `StoreError`. No source change was required and no
  `kiroku-cli` API or runtime behavior changed.

## 0.2.0.5 — 2026-08-15

### Other Changes

* Built with `ghc-options: -Wall -Werror=incomplete-patterns`, matching every
  other package in the repository. No source change was required and no
  `kiroku-cli` API or runtime behavior changed.

## 0.2.0.4 — 2026-08-13

### Other Changes

* Requires `kiroku-store ^>=0.7` for the new replay-history retention API. No
  `kiroku-cli` API or runtime behavior changed.

## 0.2.0.3 — 2026-08-12

### Other Changes

* Requires `kiroku-store ^>=0.6`, whose exported `Store` effect now offers the
  visible global head position read. No `kiroku-cli` API or runtime behavior
  changed.

## 0.2.0.2 — 2026-08-11

### Other Changes

* Requires `kiroku-store ^>=0.5`, whose exported `Store` effect now supports
  the subscription checkpoint initialization lifecycle. No `kiroku-cli` API or
  runtime behavior changed.

## 0.2.0.1 — 2026-08-09

### Other Changes

* Requires `kiroku-store ^>=0.4`, whose exported `Store` effect now supports
  durable subscription checkpoint inventory reads. No `kiroku-cli` API or
  runtime behavior changed.

## 0.2.0.0 — 2026-07-11

### Breaking Changes

* The standalone `kiroku` binary is now a pure remote client. It no longer opens
  a store, and the `--database-url`, `--schema`, and `--pool-size` options are
  gone. Subscription status is resolved from `--remote-url` or the
  `KIROKU_REMOTE_URL` environment variable and served by a running worker's
  `kiroku-metrics` `/subscriptions` endpoint; with neither set, the binary exits
  with guidance instead of connecting to a database. The embeddable library path
  (`runKirokuCommandWithStore` / `renderKirokuCommandWithStore`) still reads the
  in-process registry, so host applications are unaffected.
* `StandaloneOptions` and `StandaloneRuntime` are now newtypes carrying only
  `command :: KirokuCommand`. `StandaloneOptions` lost `databaseUrl`, `schema`,
  and `poolSize`; `StandaloneRuntime` lost `settings :: ConnectionSettings`.
  `resolveStandaloneOptions` no longer builds connection settings.
* Record field prefixes were dropped throughout the public API, so field
  selectors are renamed. `StandaloneOptions.standaloneCommand` and
  `StandaloneRuntime.runtimeCommand` both become `command`, and
  `SubscriptionStatusRow`'s `rowSubscription`, `rowMember`, `rowPhase`, and
  `rowGlobalPosition` become `subscription`, `member`, `phase`, and
  `globalPosition`. The affected records now derive `Generic`, so they are
  addressable with `generic-lens` labels (`row ^. #subscription`).
* Requires `kiroku-store ^>=0.3`.

### New Features

* `Kiroku.Cli.Subscription.Status` gains a remote client:
  `fetchRemoteSubscriptionStatusRows` and `renderRemoteSubscriptionStatus` query
  a worker's `/subscriptions` endpoint over `http-client` /`http-client-tls`.
* `SubscriptionStatusRow` gains `ToJSON` / `FromJSON` instances, giving the HTTP
  endpoint and the CLI a single wire contract; `renderJson` now encodes through
  that codec.
* `StatusOptions` gains `endpoint :: Maybe RemoteEndpoint` (`Nothing` reads the
  in-process registry; `Just` queries a remote worker), populated by the new
  `--remote-url` option.

## 0.1.0.0 — 2026-05-31

### New Features

* Initial package with embeddable parser, runner facade, executable wrapper,
  and parser composition tests.
