#!/usr/bin/env python3
"""Repair proof and fixed five-pair cases, retaining the original experiment deadline."""
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/shinzui/Keikaku/bokuno/kiroku-project/kiroku')
SPEC = importlib.util.spec_from_file_location('controller', ROOT / 'bench/ep54-cell/run.py')
C = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(C)
C.OPERATOR = '/nix/store/298a0vi9z4snf83z83zgi3fjg126v1fw-kenshou-ep54-cell-0.1.0.0/bin/ep54-operator'
C.RESULTS = C.RESULTS / 'v2'
C.RESULTS.mkdir(exist_ok=True)


def plan(mode, label):
    target = C.RESULTS / f'{label}.plan.json'
    C.command([C.OPERATOR, 'plan', '--all', '--select', 'kiroku/append/benchmark/category-namespace',
               '--placement', 'cell', '--seed', '7', '--dim', 'pg.durability=durable', '--dim', 'pg.version=18',
               '--set', f'ep54.mode={mode}', '--out', target], f'plan-{label}')
    return target


def pair(label, document, pairs):
    C.command(C.cell('pair', '--cell', 'alpha', '--start', '--baseline', C.RESULTS / 'released-payload.json',
                      '--candidate', C.RESULTS / 'head-payload.json', '--plan', document,
                      '--policy', 'bench/mp12-cell/policy.json', '--pairs', str(pairs), '--max-replacements', '0',
                      '--pg-setting', 'shared_buffers=128MB', '--pg-setting', 'fsync=on',
                      '--pg-setting', 'synchronous_commit=on', '--pg-setting', 'full_page_writes=on',
                      '--out', C.RESULTS / label), f'pair-{label}', minimum=pairs * 160, accepted=(0, 1, 3), monitor=True)
    C.status(f'{label}-released-status')
    comparison = json.loads((C.RESULTS / label / 'comparison.json').read_text())
    if comparison['verdict'] == 'regression':
        raise RuntimeError('consistent adverse comparison; stop and diagnose before adding coverage')
    return comparison


def verify_measurement_proof():
    base = C.RESULTS / 'measurement-proof'
    journal = json.loads((base / 'round-0/session.json').read_text())
    if len(journal['slices']) != 1 or any(row['state'] != 'verified' or row['cellOutcome'] != 'completed' or row['entryExitCode'] != 0 for row in journal['slices']):
        raise RuntimeError('measurement proof has invalid or unfinished slices')
    summaries = []
    for result in base.rglob('run-result.json'):
        run = json.loads(result.read_text())
        # The measurement pipeline has already validated the complete load window.
        summary = run['summaries']['measurements']['measurements']
        if run['exitCode'] or summary['grade'] != 'benchmark':
            raise RuntimeError('measurement proof lacks benchmark grade')
        probe = run['summaries']['measurements']['namespace-comparison']
        if probe['arm'] == 'candidate' and not probe['namespace']['exact_ordered_delivery']:
            raise RuntimeError('candidate namespace oracle did not pass')
        summaries.append(dict(run=run['runId'], grade=summary['grade'], arm=probe['arm']))
    if len(summaries) != 1:
        raise RuntimeError('measurement proof did not produce its candidate run result')
    C.save('measurement-proof-completed.json', summaries)


try:
    C.status('resume-before-measurement')
    C.command(C.cell('run', '--cell', 'alpha', '--start', '--payload', C.RESULTS / 'head-payload.json',
                     '--plan', C.RESULTS / 'measurement-proof.plan.json', '--out', C.RESULTS / 'measurement-proof',
                     '--pg-setting', 'checkpoint_timeout=30min', '--pg-setting', 'max_wal_size=16GB',
                     '--pg-setting', 'shared_buffers=128MB'), 'measurement-proof-single', minimum=160, monitor=True)
    C.status('measurement-proof-released-status')
    verify_measurement_proof()
    if C.remaining() < 20 * 80 + 180:
        raise RuntimeError('the fixed 20-trial queue no longer fits the remaining budget')
    for case in ['disabled', 'active']:
        pair(case, plan(case, case), 5)
finally:
    C.cleanup()
